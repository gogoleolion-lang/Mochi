// Top-level build file. Plugin versions live here; the app module applies them.
// AGP 8.13+ and Kotlin 2.0+ are required by the avatar SDK (io.github.hufeiya:corelib).
plugins {
    id("com.android.application") version "8.13.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.25" apply false
}
