package com.sherley.app.ai

import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.io.IOException
import java.net.Inet6Address
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

/**
 * One shared HTTP setup for the local Thinai model, plus readable network error messages.
 * If you keep getting timeouts, the numbers below are the first thing to change.
 */
object Http {

    /** Every network timeout is 8 minutes (480 seconds). */
    const val TIMEOUT_S = 480L
    const val CONNECT_TIMEOUT_S = TIMEOUT_S
    const val READ_TIMEOUT_S = TIMEOUT_S

    /**
     * Many mobile networks have broken IPv6 routes, which shows up as "connect timeout" while
     * everything else works. Trying IPv4 addresses first avoids that.
     */
    private object Ipv4First : Dns {
        override fun lookup(hostname: String): List<InetAddress> =
            Dns.SYSTEM.lookup(hostname).sortedBy { it is Inet6Address }
    }

    fun client(): OkHttpClient = OkHttpClient.Builder()
        .dns(Ipv4First)
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectTimeout(CONNECT_TIMEOUT_S, TimeUnit.SECONDS)
        .readTimeout(READ_TIMEOUT_S, TimeUnit.SECONDS)
        .writeTimeout(TIMEOUT_S, TimeUnit.SECONDS)
        .callTimeout(TIMEOUT_S, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Turns a low-level network exception into a sentence that says what actually failed. */
    fun explain(e: IOException): String = when (e) {
        is SocketTimeoutException ->
            if (e.message.orEmpty().contains("connect", ignoreCase = true)) {
                "Could not connect within ${CONNECT_TIMEOUT_S}s. The network may be blocking or " +
                    "throttling it. Try Wi-Fi vs mobile data, or turn off any VPN or DNS filter."
            } else {
                "Connected, but the server did not answer within ${READ_TIMEOUT_S}s."
            }
        is UnknownHostException -> "No internet connection (could not find the server)."
        is SSLException -> "Secure connection failed (${e.message}). Check the phone's date and time."
        else -> "Network problem: ${e.javaClass.simpleName} ${e.message.orEmpty()}".trim()
    }
}
