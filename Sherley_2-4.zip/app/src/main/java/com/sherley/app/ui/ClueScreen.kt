package com.sherley.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sherley.app.companion.Mood
import com.sherley.app.data.MessageEntity

/** The "case file": the full text of a long reply, on a dimmed copy of the mood background. */
@Composable
fun ClueScreen(vm: ChatViewModel, messageId: Long, onBack: () -> Unit) {
    var message by remember { mutableStateOf<MessageEntity?>(null) }
    LaunchedEffect(messageId) { message = vm.messageById(messageId) }

    val bgVersion by vm.backgrounds.version.collectAsStateWithLifecycle()
    val mood = Mood.fromName(message?.mood) ?: Mood.CURIOUS
    val bgFile = remember(mood, bgVersion) { vm.backgrounds.fileFor(mood) }

    Box(Modifier.fillMaxSize().background(Color(0xFF26324F))) {
        MoodBackground(file = bgFile, mood = mood, veilAlpha = 0.55f)

        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(16.dp),
        ) {
            TextButton(onClick = onBack) { Text("← Back", color = Color.White, fontSize = 16.sp) }
            Text(
                text = "Case file",
                color = Color(0xFFE0B25A),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
            Spacer(Modifier.height(8.dp))
            Surface(
                color = Color.Black.copy(alpha = 0.4f),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().weight(1f),
            ) {
                Text(
                    text = message?.text ?: "Opening the file…",
                    color = Color.White,
                    fontSize = 17.sp,
                    lineHeight = 25.sp,
                    modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                )
            }
        }
    }
}
