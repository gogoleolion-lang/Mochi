package com.sherley.app.avatar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neethu.corelib.AvatarView
import com.neethu.corelib.rememberAvatarController
import com.sherley.app.companion.Mood
import kotlinx.coroutines.delay

/**
 * The 3D body. Loads the VRM (picked file first, then the bundled one), shows it full screen,
 * and drives her face and pose.
 *
 * version: change it to force a reload (after picking a new VRM file in Settings).
 * onBody:  hands the AvatarBody to the caller (touch layer, camera buttons).
 * devMode: shows a panel with the model state, its expression names and test buttons.
 */
@Composable
fun AvatarScene(
    version: Int,
    mood: Mood,
    intensity: Float,
    speaking: Boolean,
    flash: Face?,
    flashKey: Int,
    pose: PoseController,
    devMode: Boolean,
    modifier: Modifier = Modifier,
    onBody: (AvatarBody) -> Unit = {},
) {
    val context = LocalContext.current
    val controller = rememberAvatarController()
    val body = remember(controller) { AvatarBody(controller) }
    var status by remember { mutableStateOf("starting") }

    LaunchedEffect(body) { onBody(body) }

    LaunchedEffect(body, version) {
        val file = AvatarModel.pickedFile(context)
        val asset = AvatarModel.bundledAsset(context)
        val force = version > 0
        when {
            file != null -> { body.loadFile(file, force); status = "picked file: ${body.stateText()}" }
            asset != null -> { body.loadAsset(asset, force); status = "$asset: ${body.stateText()}" }
            else -> status = "no .vrm found: put one in assets/vrms or pick one in Settings"
        }
        if (body.isReady()) {
            delay(300)
            status += if (body.playIdle()) " | idle animation started" else " | idle animation was not accepted"
        }
    }

    AvatarDriver(body, mood, intensity, speaking, flash, flashKey, pose)

    Box(modifier) {
        AvatarView(controller = controller, modifier = Modifier.fillMaxSize())

        if (devMode) {
            Column(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .heightIn(max = 220.dp)
                    .background(Color(0xCC000000))
                    .padding(8.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text("Avatar: $status", color = Color.White, fontSize = 11.sp)
                Text("Expressions in this model: ${body.expressionNames().joinToString()}", color = Color.LightGray, fontSize = 10.sp)
                TextButton(onClick = { status += if (body.playIdle()) " | idle ok" else " | idle failed" }) {
                    Text("Play idle animation", fontSize = 10.sp)
                }
                Row {
                    for (p in listOf("joy", "angry", "sad", "relaxed", "surprised", "blink", "aa")) {
                        TextButton(onClick = { body.setExpression(p, 1f) }) { Text(p, fontSize = 10.sp) }
                    }
                }
            }
        }
    }
}
