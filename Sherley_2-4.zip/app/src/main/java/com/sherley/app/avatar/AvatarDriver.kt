package com.sherley.app.avatar

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import com.sherley.app.companion.Mood
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/**
 * Animates her about 30 times a second: eases her face toward her mood, flashes a reaction face when
 * touched, blinks now and then, moves her mouth while she "speaks", and feeds the arm/head pose.
 */
@Composable
fun AvatarDriver(
    body: AvatarBody?,
    mood: Mood,
    intensity: Float,
    speaking: Boolean,
    flash: Face?,
    flashKey: Int,
    pose: PoseController,
) {
    val moodNow by rememberUpdatedState(mood)
    val intensityNow by rememberUpdatedState(intensity)
    val speakingNow by rememberUpdatedState(speaking)
    val flashNow by rememberUpdatedState(flash)
    val flashKeyNow by rememberUpdatedState(flashKey)

    LaunchedEffect(body) {
        if (body == null) return@LaunchedEffect
        var cur = Face()
        var nextBlinkAt = 0L
        var blinkStart = -1L
        var lastKey = flashKeyNow
        var flashFace: Face? = null
        var flashUntil = 0L
        while (true) {
            val now = System.currentTimeMillis()
            if (flashKeyNow != lastKey) {
                lastKey = flashKeyNow
                flashFace = flashNow
                flashUntil = now + 1800
            }
            var target = FaceMap.face(moodNow, intensityNow)
            flashFace?.let { if (now < flashUntil) target = target.maxWith(it) }
            cur = ease(cur, target, 0.18f)

            if (blinkStart < 0 && now >= nextBlinkAt) {
                blinkStart = now
                nextBlinkAt = now + 2500 + Random.nextLong(4000)
            }
            var blink = 0f
            if (blinkStart >= 0) {
                val t = (now - blinkStart) / 180f
                if (t >= 1f) blinkStart = -1 else blink = 1f - abs(2f * t - 1f)
            }
            val mouth = if (speakingNow) 0.25f + 0.35f * abs(sin(now / 90.0)).toFloat() else 0f

            body.applyFace(cur, blink, mouth)
            pose.frame(body, android.os.SystemClock.elapsedRealtime())
            delay(33L)
        }
    }
}

private fun ease(a: Face, b: Face, k: Float) = Face(
    a.joy + (b.joy - a.joy) * k,
    a.angry + (b.angry - a.angry) * k,
    a.sad + (b.sad - a.sad) * k,
    a.relaxed + (b.relaxed - a.relaxed) * k,
    a.surprised + (b.surprised - a.surprised) * k,
    a.eyesClosed + (b.eyesClosed - a.eyesClosed) * k,
)
