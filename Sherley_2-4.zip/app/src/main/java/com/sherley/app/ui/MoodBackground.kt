package com.sherley.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.sherley.app.companion.Mood
import com.sherley.app.companion.MoodFamily
import java.io.File

/**
 * Full-screen background. Shows the picked image (with a light dark veil so text stays readable),
 * or a gradient tinted by the mood family when no image is set.
 */
@Composable
fun MoodBackground(file: File?, mood: Mood, veilAlpha: Float = 0.25f) {
    if (file != null) {
        AsyncImage(
            model = file,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = veilAlpha)))
    } else {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(familyColors(mood.family))))
    }
}

/** Fallback gradient per family. */
fun familyColors(family: MoodFamily): List<Color> = when (family) {
    MoodFamily.JOY -> listOf(Color(0xFF6B4E16), Color(0xFF2B1D07))
    MoodFamily.ENERGY -> listOf(Color(0xFF7A2E1B), Color(0xFF2B100A))
    MoodFamily.FOCUS -> listOf(Color(0xFF1E3A4C), Color(0xFF0A1520))
    MoodFamily.CALM -> listOf(Color(0xFF2E4A3A), Color(0xFF0E1B14))
    MoodFamily.LOW_ENERGY -> listOf(Color(0xFF3A3550), Color(0xFF12101C))
    MoodFamily.SADNESS -> listOf(Color(0xFF26324A), Color(0xFF0B0F1A))
    MoodFamily.IRRITATION -> listOf(Color(0xFF5A2222), Color(0xFF1E0A0A))
    MoodFamily.SOCIAL -> listOf(Color(0xFF5A3A55), Color(0xFF1D111C))
}
