package com.sherley.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.lifecycle.viewmodel.compose.viewModel

/** Where you are. Every screen except Main is drawn on top of Main. */
sealed interface Screen {
    data object Main : Screen
    data class Clue(val id: Long) : Screen
    data object History : Screen
    data object Backgrounds : Screen
    data object Settings : Screen
    data object Apps : Screen
}

/**
 * Navigation by overlay. MainScreen (with the 3D avatar) stays alive underneath all the time,
 * so opening Settings or History never reloads the model. One shared ChatViewModel serves all.
 */
@Composable
fun SherleyApp() {
    val vm: ChatViewModel = viewModel()
    var screen by remember { mutableStateOf<Screen>(Screen.Main) }
    var previous by remember { mutableStateOf<Screen>(Screen.Main) }
    var hideUi by remember { mutableStateOf(false) }

    fun go(to: Screen) { previous = screen; screen = to }
    fun back() { screen = if (screen is Screen.Clue && previous is Screen.History) Screen.History else Screen.Main }

    BackHandler(enabled = screen != Screen.Main) { back() }

    Box(Modifier.fillMaxSize()) {
        MainScreen(
            vm = vm,
            hideUi = hideUi,
            onToggleUi = { hideUi = !hideUi },
            onOpenClue = { go(Screen.Clue(it)) },
            onHistory = { go(Screen.History) },
            onBackgrounds = { go(Screen.Backgrounds) },
            onSettings = { go(Screen.Settings) },
            onApps = { go(Screen.Apps) },
        )

        if (screen != Screen.Main) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    // An empty pointerInput still takes part in hit testing, so touches never reach the avatar below.
                    .pointerInput(Unit) {},
            ) {
                when (val s = screen) {
                    Screen.Main -> {}
                    is Screen.Clue -> ClueScreen(vm = vm, messageId = s.id, onBack = ::back)
                    Screen.History -> HistoryScreen(vm = vm, onOpenClue = { go(Screen.Clue(it)) }, onBack = ::back)
                    Screen.Backgrounds -> BackgroundsScreen(vm = vm, onBack = ::back)
                    Screen.Settings -> SettingsScreen(vm = vm, onBack = ::back)
                    Screen.Apps -> AppDrawerScreen(onBack = ::back)
                }
            }
        }
    }
}
