package com.sherley.app.reflex

import com.sherley.app.companion.Mood
import com.sherley.app.companion.MoodFamily
import kotlin.random.Random

/**
 * Instant reactions that need no language model: the little remarks she makes when it has been quiet.
 * (Touch reactions live in avatar/Reactions.kt.) Pre-written, picked by mood family. Add your own!
 */
object ReflexLines {

    /** Remarks she makes on her own after a quiet stretch. Never needy or guilt-tripping. */
    fun idleBark(mood: Mood, random: Random = Random.Default): String {
        val pool = when (mood.family) {
            MoodFamily.JOY, MoodFamily.ENERGY -> listOf("I've been humming the case theme. Want to hear a riddle?", "Deduction of the hour: it's a good day.")
            MoodFamily.FOCUS -> listOf("Hm, I just thought of something odd. Ask me later.", "Still thinking about that last clue...")
            MoodFamily.CALM -> listOf("Quiet is nice too, you know.", "I'm just enjoying the view from my corner.")
            MoodFamily.LOW_ENERGY -> listOf("*yawn* ...I'm awake. Mostly.", "Wake me if something mysterious happens.")
            MoodFamily.SADNESS -> listOf("It got quiet. That's okay. I'm here if you want to talk.", "Thinking about Baker Street. Cozy place.")
            MoodFamily.IRRITATION -> listOf("Hmph.", "I'm not sulking. I'm observing. Silently.")
            MoodFamily.SOCIAL -> listOf("Um, hi. Just checking nothing's wrong.", "Psst. Got any secrets for me to deduce?")
        }
        return pool.random(random)
    }
}
