package com.sherley.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.sherley.app.companion.Mood
import com.sherley.app.companion.MoodFamily
import com.sherley.app.data.BackgroundStore

/**
 * One slot per mood plus a default. Pick a picture from your gallery for each.
 * A mood without its own picture falls back to the default one.
 */
@Composable
fun BackgroundsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val version by vm.backgrounds.version.collectAsStateWithLifecycle()
    var targetKey by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val key = targetKey
        if (uri != null && key != null) vm.setBackground(key, uri)
        targetKey = null
    }
    fun pick(key: String) {
        targetKey = key
        picker.launch("image/*")
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
        TextButton(onClick = onBack) { Text("← Back", fontSize = 16.sp) }
        Text(
            text = "Backgrounds",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                SlotRow(
                    title = "Default (used when a mood has no picture)",
                    key = BackgroundStore.DEFAULT_KEY,
                    version = version,
                    vm = vm,
                    onPick = ::pick,
                )
            }
            for (family in MoodFamily.values()) {
                item {
                    Text(
                        text = family.label,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 12.dp),
                    )
                }
                for (mood in Mood.values().filter { it.family == family }) {
                    item(key = mood.name) {
                        SlotRow(title = mood.label, key = mood.name, version = version, vm = vm, onPick = ::pick)
                    }
                }
            }
        }
    }
}

@Composable
private fun SlotRow(
    title: String,
    key: String,
    version: Int,
    vm: ChatViewModel,
    onPick: (String) -> Unit,
) {
    val file = remember(key, version) { vm.backgrounds.exactFile(key) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surface),
        ) {
            if (file != null) {
                AsyncImage(
                    model = file,
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Text(text = title, modifier = Modifier.weight(1f), fontSize = 15.sp)
        OutlinedButton(onClick = { onPick(key) }) { Text(if (file == null) "Pick" else "Change") }
        if (file != null) {
            TextButton(onClick = { vm.clearBackground(key) }) { Text("Clear") }
        }
    }
}
