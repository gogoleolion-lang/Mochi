package com.sherley.app.avatar

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** One beat of a touch reaction: hold [apply]'s pose for [ms] milliseconds. */
class Step(val ms: Long, val apply: (Pose) -> Pose)

/**
 * Decides what pose is fed to the avatar each frame. Priority:
 *   1. the pose you are editing  2. a touch-reaction gesture  3. your saved pose  4. nothing (her idle animation)
 */
class PoseController(initialSaved: Pose?, private val persist: (Pose?) -> Unit) {

    var saved by mutableStateOf(initialSaved); private set
    var editing by mutableStateOf<Pose?>(null); private set
    var editJoint by mutableStateOf<Joint?>(null); private set

    private var steps: List<Step> = emptyList()
    private var gestureStart = 0L
    private var engaged = false
    private var lastPose: Pose? = null

    /** The pose she is in right now (used to place the touch spots on her arms). */
    fun displayPose(): Pose = lastPose ?: saved ?: Pose.NATURAL

    // ---- Editing ----------------------------------------------------------------
    fun beginEdit(joint: Joint) {
        if (editing == null) editing = saved ?: Pose.NATURAL
        editJoint = joint
        steps = emptyList()
    }

    fun aimJoint(dir: FloatArray) {
        val p = editing ?: return
        editing = when (editJoint) {
            Joint.NECK -> p.withHead(dir)
            Joint.SHOULDER_L -> p.arm(1, upper = dir)
            Joint.SHOULDER_R -> p.arm(-1, upper = dir)
            Joint.ELBOW_L -> p.arm(1, lower = dir)
            Joint.ELBOW_R -> p.arm(-1, lower = dir)
            null -> p
        }
    }

    /** Keep the edited pose; she holds it until you reset it. */
    fun save() {
        saved = editing
        editing = null
        editJoint = null
        persist(saved)
    }

    /** Throw the edit away: back to the pose before it (your saved pose, or her natural one). */
    fun discard() {
        editing = null
        editJoint = null
    }

    /** Forget any saved pose and return to her natural animation. */
    fun natural() {
        editing = null
        editJoint = null
        saved = null
        persist(null)
    }

    // ---- Touch-reaction gestures --------------------------------------------------
    fun play(gesture: List<Step>) {
        if (editing != null) return
        steps = gesture
        gestureStart = SystemClock.elapsedRealtime()
    }

    /** Called about 30 times a second by the avatar driver. */
    fun frame(body: AvatarBody, now: Long) {
        val pose = editing ?: gesturePose(now) ?: saved
        lastPose = pose
        if (pose != null) {
            body.controller.setMimicPose(pose.toMimic())
            engaged = true
        } else if (engaged) {
            body.controller.clearMimicPose()
            engaged = false
        }
    }

    private fun gesturePose(now: Long): Pose? {
        if (steps.isEmpty()) return null
        var t = now - gestureStart
        val base = saved ?: Pose.NATURAL
        for (s in steps) {
            if (t < s.ms) return s.apply(base)
            t -= s.ms
        }
        steps = emptyList()
        return null
    }
}
