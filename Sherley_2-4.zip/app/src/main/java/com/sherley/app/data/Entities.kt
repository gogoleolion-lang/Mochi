package com.sherley.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One chat message. role is "user" or "model". The full text is kept here forever. */
@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val text: String,
    val timestamp: Long,
    /** Mood name (from the Mood enum) Sherley was in after writing this reply. */
    val mood: String? = null,
)

/** One long-term memory about the user, e.g. "Al-Haitham likes chess". */
@Entity(tableName = "facts")
data class FactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long,
)
