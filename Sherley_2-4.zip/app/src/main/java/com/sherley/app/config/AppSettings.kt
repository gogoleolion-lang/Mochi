package com.sherley.app.config

import android.content.Context

/** Everything the user can change at runtime, saved on the phone (SharedPreferences). */
class AppSettings(context: Context) {

    private val prefs = context.getSharedPreferences("sherley_settings", Context.MODE_PRIVATE)

    private fun str(key: String, default: String) = prefs.getString(key, default) ?: default
    private fun putStr(key: String, value: String) = prefs.edit().putString(key, value).apply()
    private fun putBool(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()

    // ---- Editable in the Settings screen -------------------------------
    /** Where Thinai's local server listens. */
    var localUrl: String
        get() = str("local_url", AppConfig.DEFAULT_LOCAL_URL)
        set(v) = putStr("local_url", v.trim().ifBlank { AppConfig.DEFAULT_LOCAL_URL })

    /** Model name inside Thinai. Blank means "use the first model Thinai reports". */
    var localModel: String
        get() = str("local_model", "")
        set(v) = putStr("local_model", v.trim())

    var userName: String
        get() = str("user_name", AppConfig.DEFAULT_USER_NAME)
        set(v) = putStr("user_name", v.trim().ifBlank { AppConfig.DEFAULT_USER_NAME })

    var historyTurns: Int
        get() = prefs.getInt("history_turns", AppConfig.DEFAULT_HISTORY_TURNS)
        set(v) = prefs.edit().putInt("history_turns", v.coerceIn(2, 30)).apply()

    // ---- Avatar switches ---------------------------------------------------
    /** Show the 3D body at all. */
    var avatarEnabled: Boolean
        get() = prefs.getBoolean("avatar_enabled", true)
        set(v) = putBool("avatar_enabled", v)

    /** Eyes follow your finger. Off by default: needs the SDK's look-at call to behave. */
    var eyeFollow: Boolean
        get() = prefs.getBoolean("eye_follow", false)
        set(v) = putBool("eye_follow", v)

    /** Shows touch zones and a diagnostics panel on the main screen. */
    var devMode: Boolean
        get() = prefs.getBoolean("dev_mode", false)
        set(v) = putBool("dev_mode", v)

    /** Draw the mood background image behind the avatar (may hide it, depends on the SDK's surface). */
    var bgBehindAvatar: Boolean
        get() = prefs.getBoolean("bg_behind_avatar", false)
        set(v) = putBool("bg_behind_avatar", v)

    /** Her saved arm/head pose (JSON of 15 numbers), or blank for her natural animation. */
    var poseJson: String
        get() = str("pose_json", "")
        set(v) = putStr("pose_json", v)

    // ---- Saved automatically by the app ----------------------------------
    /** Where the user dragged the text box and the speech bubble (pixels from their default spot). */
    var inputOffsetX: Float
        get() = prefs.getFloat("input_offset_x", 0f)
        set(v) = prefs.edit().putFloat("input_offset_x", v).apply()

    var inputOffsetY: Float
        get() = prefs.getFloat("input_offset_y", 0f)
        set(v) = prefs.edit().putFloat("input_offset_y", v).apply()

    var bubbleOffsetX: Float
        get() = prefs.getFloat("bubble_offset_x", 0f)
        set(v) = prefs.edit().putFloat("bubble_offset_x", v).apply()

    var bubbleOffsetY: Float
        get() = prefs.getFloat("bubble_offset_y", 0f)
        set(v) = prefs.edit().putFloat("bubble_offset_y", v).apply()

    /** Sherley's needs + current mood, as JSON (see MoodState). */
    var moodStateJson: String
        get() = str("mood_state", "")
        set(v) = putStr("mood_state", v)

    /** Rolling summary of old conversations. */
    var summaryText: String
        get() = str("summary_text", "")
        set(v) = putStr("summary_text", v)

    /** Highest message id already folded into the summary. */
    var summarizedUpToId: Long
        get() = prefs.getLong("summarized_up_to", 0L)
        set(v) = prefs.edit().putLong("summarized_up_to", v).apply()
}
