package com.sherley.app.avatar

import com.neethu.corelib.AvatarController
import com.neethu.corelib.AvatarState
import java.io.File

/** Camera axes in world space: where screen-right, screen-up and "toward the viewer" point. */
class CameraBasis(val right: FloatArray, val up: FloatArray, val toViewer: FloatArray)

/**
 * Sherley's body: the small set of things the app asks the 3D model to do.
 * A thin, typed wrapper over the library's AvatarController.
 */
class AvatarBody(val controller: AvatarController) {

    /** Name variants models use for the same expression. The first one the model really has wins. */
    private val candidates = mapOf(
        "joy" to listOf("joy", "happy"),
        "angry" to listOf("angry"),
        "sad" to listOf("sorrow", "sad"),
        "relaxed" to listOf("relaxed", "fun"),
        "surprised" to listOf("surprised"),
        "blink" to listOf("blink"),
        "aa" to listOf("aa", "a"),
    )
    private var resolved: Map<String, String?>? = null

    /** Call after a model load so expression names are looked up again. */
    fun invalidate() { resolved = null }

    fun expressionNames(): List<String> = controller.getAvailableExpressions()

    private fun resolve(preset: String): String? {
        var map = resolved
        if (map == null) {
            val avail = controller.getAvailableExpressions()
            if (avail.isEmpty()) return null
            val byLower = avail.associateBy { it.lowercase() }
            map = candidates.mapValues { (_, names) -> names.firstNotNullOfOrNull { byLower[it] } }
            resolved = map
        }
        return map[preset]
    }

    fun setExpression(preset: String, value: Float) {
        val name = resolve(preset) ?: return
        controller.setExpression(name, value.coerceIn(0f, 1f))
    }

    fun applyFace(f: Face, blink: Float, mouth: Float) {
        setExpression("joy", f.joy)
        setExpression("angry", f.angry)
        setExpression("sad", f.sad)
        setExpression("relaxed", f.relaxed)
        setExpression("surprised", f.surprised)
        setExpression("blink", maxOf(blink, f.eyesClosed))
        setExpression("aa", mouth)
    }

    // ---- Loading ------------------------------------------------------------
    fun loadAsset(path: String, force: Boolean) { invalidate(); controller.loadModel(path, force) }
    fun loadFile(file: File, force: Boolean) { invalidate(); controller.loadModelFromFile(file.absolutePath, force) }

    fun isReady() = controller.state.value is AvatarState.Ready
    fun stateText(): String = when (val s = controller.state.value) {
        is AvatarState.Idle -> "Idle"
        is AvatarState.Loading -> "Loading"
        is AvatarState.Ready -> "Ready"
        is AvatarState.Error -> "Error: ${s.message}"
    }

    /**
     * Starts the looping idle animation (arms down, gentle breathing) from assets/vrmas/idle.vrma.
     * Without an animation a VRM stands in its default T-pose.
     */
    fun playIdle(path: String = "vrmas/idle.vrma"): Boolean {
        val ok = controller.setVrmaIdleAnimation(path)
        controller.stopVrmaAnimation(0f) // "stop" returns to the idle loop when one is set
        return ok
    }

    // ---- Camera ---------------------------------------------------------------
    fun zoom(spreadPx: Float) = controller.zoomCamera(spreadPx)
    fun orbit(yawPx: Float, pitchPx: Float) = controller.orbitCamera(yawPx, pitchPx)
    fun pan(dxPx: Float, dyPx: Float) = controller.panCamera(dxPx, dyPx)
    fun resetCamera() = controller.resetCamera()

    fun cameraBasis(): CameraBasis? {
        val (eye, target, up) = controller.getCameraLookAt() ?: return null
        val f = V.norm(target[0] - eye[0], target[1] - eye[1], target[2] - eye[2])
        val right = V.cross(f, up).let { V.norm(it[0], it[1], it[2]) }
        val upv = V.cross(right, f).let { V.norm(it[0], it[1], it[2]) }
        return CameraBasis(right, upv, floatArrayOf(-f[0], -f[1], -f[2]))
    }

    /** Eyes toward a point on screen (-1..1 each axis). Only used when "eyes follow finger" is on. */
    fun lookAtScreen(x: Float, y: Float) {
        val (eye, _, _) = controller.getCameraLookAt() ?: return
        val b = cameraBasis() ?: return
        controller.setLookAtTarget(
            eye[0] + b.right[0] * x * 0.8f - b.up[0] * y * 0.8f,
            eye[1] + b.right[1] * x * 0.8f - b.up[1] * y * 0.8f,
            eye[2] + b.right[2] * x * 0.8f - b.up[2] * y * 0.8f,
        )
    }

    // ---- Where she is on screen ------------------------------------------------
    // The library release this app uses has no "head position" or "project to screen" call, so both
    // are worked out here. The renderer scales every model to a 2-unit-tall cube standing on the feet.

    fun feetWorld(): FloatArray? = FloatArray(3).takeIf { controller.avatarWorldPos(it) }

    fun headTopWorld(): FloatArray? = feetWorld()?.let { floatArrayOf(it[0], it[1] + MODEL_HEIGHT, it[2]) }

    /**
     * World point to normalized screen coordinates (0..1, top-left origin) using the camera's
     * position and its look-at, or null if the point is behind the camera.
     */
    fun project(x: Float, y: Float, z: Float, aspect: Float): FloatArray? {
        val (eye, target, up) = controller.getCameraLookAt() ?: return null
        val f = V.norm(target[0] - eye[0], target[1] - eye[1], target[2] - eye[2])
        val r = V.cross(f, up).let { V.norm(it[0], it[1], it[2]) }
        val u = V.cross(r, f)
        val dx = x - eye[0]
        val dy = y - eye[1]
        val dz = z - eye[2]
        val depth = dx * f[0] + dy * f[1] + dz * f[2]
        if (depth <= 0.01f) return null
        val ndcX = (dx * r[0] + dy * r[1] + dz * r[2]) / (depth * HALF_FOV_TAN * aspect)
        val ndcY = (dx * u[0] + dy * u[1] + dz * u[2]) / (depth * HALF_FOV_TAN)
        return floatArrayOf((ndcX + 1f) * 0.5f, (1f - ndcY) * 0.5f)
    }

    private companion object {
        /** Height of the normalized model in world units (a 2-unit cube). */
        const val MODEL_HEIGHT = 2.0f

        /** Half the vertical field of view as a tangent: a 28 mm lens on a 24 mm sensor height. */
        const val HALF_FOV_TAN = 12f / 28f
    }
}
