package com.sherley.app.data

import android.content.Context
import android.net.Uri
import com.sherley.app.companion.Mood
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/**
 * Keeps the background pictures. Each mood can have its own image; "DEFAULT" is the fallback.
 * Images are copied into the app's private storage, so they survive even if you delete the original.
 */
class BackgroundStore(private val context: Context) {

    private val dir = File(context.filesDir, "backgrounds").apply { mkdirs() }

    /** Increases whenever an image changes, so screens know to reload. */
    val version = MutableStateFlow(0)

    /** The image for this mood, or the default image, or null (the UI then draws a gradient). */
    fun fileFor(mood: Mood): File? = exactFile(mood.name) ?: exactFile(DEFAULT_KEY)

    /** The image set exactly for this key (a Mood name or DEFAULT_KEY), without falling back. */
    fun exactFile(key: String): File? = File(dir, "$key.img").takeIf { it.exists() }

    fun save(key: String, uri: Uri) {
        val target = File(dir, "$key.img")
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        }
        version.value = version.value + 1
    }

    fun clear(key: String) {
        File(dir, "$key.img").delete()
        version.value = version.value + 1
    }

    companion object {
        const val DEFAULT_KEY = "DEFAULT"
    }
}
