package com.sherley.app.companion

/**
 * A free, instant backup for mood events. Small local models often forget to tag events,
 * so the app also spots obvious ones itself from simple word lists. Both sources are combined.
 * Edit the lists to teach her new triggers.
 */
object EventHeuristics {

    private val rules: List<Pair<ChatEvent, List<String>>> = listOf(
        ChatEvent.THANKS to listOf("thank", "thx", "appreciate"),
        ChatEvent.COMPLIMENT to listOf(
            "you're smart", "you are smart", "you're clever", "you are clever", "good job", "well done",
            "great job", "impressive", "genius", "brilliant", "you're awesome", "you are awesome", "love you",
        ),
        ChatEvent.INSULT to listOf(
            "stupid", "idiot", "dumb", "shut up", "useless", "hate you", "you suck", "annoying", "worthless",
        ),
        ChatEvent.APOLOGY to listOf("sorry", "i apologize", "my bad", "forgive me"),
        ChatEvent.PUZZLE to listOf("riddle", "puzzle", "mystery", "case", "clue", "solve", "whodunit", "deduce"),
        ChatEvent.JOKE to listOf("haha", "lol", "joke", "funny", "hehe"),
        ChatEvent.GREETING to listOf("hello", "hi sherley", "hey sherley", "good morning", "good evening", "hey there"),
        ChatEvent.GOODBYE to listOf("goodbye", "good night", "bye", "see you", "gotta go", "talk later"),
        ChatEvent.USER_STRESSED to listOf("stressed", "overwhelmed", "anxious", "worried about", "so much pressure"),
        ChatEvent.USER_SAD to listOf("i'm sad", "i am sad", "feeling down", "feel lonely", "feel bad", "depressed"),
        ChatEvent.USER_HAPPY to listOf("i'm happy", "i am happy", "great day", "so excited", "good news"),
        ChatEvent.CORRECTED to listOf("you're wrong", "you are wrong", "that's wrong", "that is wrong", "incorrect", "not true"),
        ChatEvent.OTHER_ASSISTANT to listOf("chatgpt", "gemini", "siri", "alexa", "copilot", "other ai"),
        ChatEvent.CHALLENGE to listOf("bet you can't", "i bet", "prove it", "can you figure", "challenge"),
    )

    fun detect(message: String): List<ChatEvent> {
        val t = message.lowercase().replace('’', '\'')
        return rules.filter { (_, words) -> words.any { t.contains(it) } }.map { it.first }
    }
}
